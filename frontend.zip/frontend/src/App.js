import React from 'react'
import LoginPage from './Pages/LoginPage/LoginPage'

const App = () => {
  return (
    <p><LoginPage/></p>
  )
}

export default App